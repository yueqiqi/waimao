// pages/detail/detail.js
const app = getApp();
// const rpn = require("../../utils/rpn.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    purchase_num: 1,
    goods: {},
    is_show: true,
    Type: '',
    id: '',
    attr: {},
    attrList: [],
    choose_img: '',
    chooseActive: '100',
    money: '',
    if_show: false,
    group_all: '',
    hour: '',
    minute: '',
    second: '',
    show_time: true,
    death_time: 1,
    death_info: '',
    finish_time: [],
    timer: '',
    one_title: '',

    id1: '0',
    id2: '0',
    id3: '0',
    canbuy: false,
    attr_id: '',
    is_inv: false,
    just_id: '',
    id_one: '',
    idArr: [],
    clickState: [],
    activeAttr: []
  },
  handIns(e) {
    var num = this.data.purchase_num;
    if (num <= 1) {
      this.setData({
        purchase_num: num
      })
    } else {
      num--;
      this.setData({
        purchase_num: num
      })
    }
  },
  handPlus() {
    var num = this.data.purchase_num;
    num++;
    this.setData({
      purchase_num: num
    })
  },
  by_self(e) {
    var that = this;
    that.setData({
      Type: e.target.dataset.id,
      id1: '0',
      id2: '0',
      id3: '0',
    })
    wx.request({
      url: app.buildUrl('/activity/get-active-attr'),
      header: app.buildHeader(),
      data: {
        aid: that.data.id,
        type: that.data.Type
      },
      success: function (res) {
        if (res.data.code == 200) {
          let list = res.data.data.attrlist
          if (list.length == 0) {
            wx.navigateTo({
              url: '/pages/order/order?attr_id=' + res.data.data.attrone.id + '&num=1&type=' + that.data.Type
            });
          } else {
            for (let i = 0; i < list.length; i++) {
              for (let j = 0; j < list[i].val.length; j++) {
                list[i].val[j].active = false;
                list[i].val[j].disable = false;
              }
            }
            let idArr = new Array(list.length);
            let clickState = new Array(list.length);
            for (let i = 0; i < idArr.length; i++) {
              idArr[i] = " ";
              clickState[i] = {
                idx: i,
                click: false
              }
            }
            that.setData({
              attr: res.data.data,
              attrList: list,
              activeAttr: res.data.data.active_attr,
              choose_img: res.data.data.list_img,
              idArr: idArr,
              clickState: clickState,
              is_show: false
            });
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            duration:1200,
            icon:'none'
          })
        }
      }
    })
  },
  by_team(e) {
    var that = this;
    that.setData({
      Type: e.target.dataset.id,
      id1: '0',
      id2: '0',
      id3: '0',
    })
    wx.request({
      url: app.buildUrl('/activity/get-active-attr'),
      header: app.buildHeader(),
      data: {
        aid: that.data.id,
        type: that.data.Type
      },
      success: function (res) {
        if (res.data.code == 200) {
          let list = res.data.data.attrlist;
          if (list.length == 0) {
            wx.navigateTo({
              url: '/pages/order/order?attr_id=' + res.data.data.attrone.id + '&num=1&type=' + that.data.Type
            });
          } else {
            for (let i = 0; i < list.length; i++) {
              for (let j = 0; j < list[i].val.length; j++) {
                list[i].val[j].active = false;
                list[i].val[j].disable = false;
              }
            }
            let idArr = new Array(list.length);
            let clickState = new Array(list.length);
            for (let i = 0; i < idArr.length; i++) {
              idArr[i] = " ";
              clickState[i] = {
                idx: i,
                click: false
              }
            }
            that.setData({
              attr: res.data.data,
              attrList: list,
              idArr: idArr,
              clickState: clickState,
              activeAttr: res.data.data.active_attr,
              choose_img: res.data.data.list_img,
              is_show: false
            });
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            duration: 1200,
            icon: 'none',
          })
        }
      }
    })
  },
  choose_typea: function (e) {
    var that = this;
    let id = e.target.dataset.id;
    let idx = e.target.dataset.idx;
    let list = that.data.attrList;
    let item = '';
    if (e.target.dataset.disable) {
      return;
    }
    list[idx].val.forEach(i => {
      if (i.id == id) {
        item = i
      }
    })
    if (!item.active) {
      list[idx].val.forEach(i => {
        if (i.id == id) {
          i.active = true;
        } else {
          i.active = false;
        }
      })
    } else {
      list[idx].val.forEach(i => {
        if (i.id == id) {
          i.active = false;
        }
      })
    }
    that.funFilter(e)
    that.setData({
      attrList: list
    })
  },
  funFilter(e) {
    let that = this;
    let id = e.target.dataset.id;
    let idx = e.target.dataset.idx;
    let list = that.data.attrList;
    let idArr = that.data.idArr;
    let newArr = [];
    let allId = [];
    let newAllId = [];
    let activeAttr = that.data.activeAttr;
    let selectState = false;
    let item = '';
    let clickState = that.data.clickState;
    list[idx].val.forEach(i => {
      if (i.id == id) {
        item = i
      }
    })
    if (!item.active) {
      id = "";
      idArr[idx] = ' ';
      clickState[idx].click = false
    } else {
      for (let i = 0; i < idArr.length; i++){
        idArr[i] = " ";
      }
      idArr[idx] = id;
      clickState[idx].click = true
    }
    // let reg = new RegExp(idArr.join('\-').replace(/\s/g, '\\d*'));
    let reg = new RegExp(id);
    activeAttr.forEach(i => {
      if (reg.test(i.attribute_value_id.trim())) {
        newArr.push(i);
      }
    })
    newArr.forEach(i => {
      allId = allId.concat(i.attribute_value_id.split('-'));
    })
    allId = allId.sort();
    for (let i = 0; i < allId.length; i++) {
      if (allId[i] !== allId[i + 1]) {
        newAllId.push(allId[i])
      }
    } 

    let num = 0;
    let s = false;
    clickState.forEach(i => {
      if (i.click) {
        num++;
      }
    })
    if (num > 0) {
      s = true;
    } else {
      s = false;
    }
    let n = '';
    if (num == 1) {
      clickState.forEach(i => {
        if (i.click) {
          n = i.idx;
        }
      })
      list[n].val.forEach(k => {
        k.disable = false;
      })
    }
    if (!s) {
      for (let i = 0; i < list.length; i++) {
        list[i].val.forEach(k => {
          k.disable = false;
        })
      }
    } else {
      for (let i = 0; i < list.length; i++) {
        if (i == idx) { continue }
        list[i].val.forEach(k => {
          if (newAllId.indexOf(k.id) == -1) {
            k.disable = true;
          } else {
            k.disable = false;
          }
        })
      }
    }
    if (!item.active) {
      let b = idx;
      for (let i = 0; i < list.length; i++) {
        if (i == b) { continue }
        list[i].val.forEach(k => {
          k.disable = false;
        })
      }
    } 
    
    num == clickState.length ? selectState = true : selectState = false;
    if (selectState) {
      let activeAttr = that.data.activeAttr;
      let arr = [];
      let arr2 = [];
      list.forEach(i => {
        i.val.forEach(k => {
          if (k.active) {
            arr.push(k.id)
          }
        })
      })
      arr = arr.sort();
      for(let i = 0; i < arr.length; i++){
        if(arr[i] == 0){
          arr[i] = "";
        }
      }
      activeAttr.forEach(i => {
        arr2 = i.attribute_value_id.split('-').sort();
        for (let i = 0; i < arr2.length; i++) {
          if (arr2[i] == 0) {
            arr2[i] = "";
          }
        }
        if (arr.join('').trim() == arr2.join('').trim()){
          // console.log(arr.join('').trim() , arr2.join('').trim())
          // console.log(i)
          if (that.data.Type == 1) {
            that.setData({
              money: i.collage_price || 0.00
            })
          } else if (that.data.Type == 2) {
            that.setData({
              money: i.one_price || 0.00
            })
          }
          that.setData({
            choose_img: i.attr_img
          })
        }
      })
      that.setData({
        is_inv: true
      })
    } else {
      that.setData({
        is_inv: false
      })
    }
    that.setData({
      attrList: list,
      idArr: idArr
    })
  },
  no_ref() {
    wx.showToast({
      title: '存货为空',
      duration: 1200,
      icon: 'none'
    })
  },
  close_filter() {
    let idArr = new Array(this.data.attrList.length);
    for (let i = 0; i < idArr.length; i++) {
      idArr[i] = " ";
    }
    this.setData({
      is_show: true,
      is_inv: false,
      idArr: idArr
    })
  },
  gotoorder() {
    wx.navigateTo({
      url: '/pages/apply_detail/apply_detail',
    })
  },
  timestampToTime(timestamp) {
    var date = new Date(timestamp * 1000);
    var y = date.getFullYear();
    var mo = date.getMonth() * 1 + 1;
    var d = date.getDay() * 1 + 1;
    var h = date.getHours();
    var m = date.getMinutes();
    var s = date.getSeconds();
    if (h.toString().length != 2) {
      h = '0' + h
    }
    if (m.toString().length != 2) {
      m = '0' + m
    }
    if (s.toString().length != 2) {
      s = '0' + s
    }
    return y + '-' + mo + '-' + d + ' ' + h + ':' + m + ':' + s;
  },
  submit() {
    var that = this;
    var attr_id = that.data.attr_id;
    var num = that.data.purchase_num;
    var typee = that.data.Type;
    if (!that.data.is_inv) {
      wx.showToast({
        title: '请选择规格',
        icon: 'none',
        duration: 1500
      })
    } else {
      let list = that.data.attrList;
      let activeAttr = that.data.activeAttr;
      let arr = [];
      let arr2 = [];
      list.forEach(i => {
        i.val.forEach(k => {
          if (k.active) {
            arr.push(k.id)
          }
        })
      })
      arr = arr.sort();
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] == 0) {
          arr[i] = "";
        }
      }
      activeAttr.forEach(i => {
        arr2 = i.attribute_value_id.split('-').sort();
        for (let i = 0; i < arr2.length; i++) {
          if (arr2[i] == 0) {
            arr2[i] = "";
          }
        }
        if (arr.join('').trim() == arr2.join('').trim()) {

          attr_id = i.id;
          
        }
      })
      // console.log(reg, attr_id)
      that.setData({
        is_show: true
      })
      // return;
      wx.navigateTo({
        url: '/pages/order/order?attr_id=' + attr_id + '&num=' + num + '&type=' + typee
      });
      app.globalData.unload = 1;
    }
  },
  death: function () {
    wx.showToast({
      title: '活动已过期或不存在',
      duration: 1200,
      icon: 'none'
    })
  },
  refresh() {
    var that = this;
    wx.redirectTo({
      url: '/pages/detail/detail?id=' + that.data.id,
    })
  },
  // 查看图片
  preview(e) {
    var that = this;
    var imgUrl = e.target.dataset.img;
    wx.previewImage({
      current: imgUrl, // 当前显示图片的http链接
      urls: that.data.goods.googs.banner
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.id) {
      this.data.id = options.id;
    } else {
      this.data.id = options.scene ? decodeURIComponent(options.scene) : '1';
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.setData({
      canbuy: false,
      is_inv: false
    })
    clearInterval(that.data.timer);
    var timer1 = setInterval(function () {
      var token = wx.getStorageSync('token');
      if (token != '') {
        wx.request({
          url: app.buildUrl('/activity/get-activity-info'),
          header: app.buildHeader(),
          data: {
            aid: that.data.id
          },
          success: function (res) {
            clearInterval(timer1)
            var newArr = [];
            that.setData({
              group_all: res.data.data.group_all
            });
            that.data.group_all.forEach((item, i) => {
              var newArr1 = that.timestampToTime(item.group.complete_time)
              newArr.push(newArr1)
              that.setData({
                finish_time: newArr
              })
            })
            if (res.data.code == 200) {
              that.setData({
                goods: res.data.data
              });
              if (res.data.data.group_one == '') {
                that.setData({
                  one_title: 0
                });
              } else if (res.data.data.group_one.one_title == 0) {
                that.setData({
                  one_title: 0
                });
              } else {
                that.setData({
                  one_title: 1
                });
              }
              if (res.data.data.group_one.re_time) {
                that.setData({
                  show_time: false,
                  hour: res.data.data.group_one.re_time.hours,
                  minute: res.data.data.group_one.re_time.minute,
                  second: res.data.data.group_one.re_time.sec
                });
                if (res.data.data.group_one.re_time.hours.toString().length != 2) {
                  that.setData({
                    hour: '0' + res.data.data.group_one.re_time.hours
                  })
                }
                if (res.data.data.group_one.re_time.minute.toString().length != 2) {
                  that.setData({
                    minute: '0' + res.data.data.group_one.re_time.minute
                  })
                }
                if (res.data.data.group_one.re_time.sec.toString().length != 2) {
                  that.setData({
                    second: '0' + res.data.data.group_one.re_time.sec
                  })
                }
                that.data.timer = setInterval(function () {
                  var hr = that.data.hour, min = that.data.minute, secd = that.data.second;
                  secd--;
                  if (secd.toString().length != 2) {
                    that.setData({
                      second: '0' + secd
                    })
                  } else {
                    that.setData({
                      second: secd
                    })
                  }
                  if (secd < 0) {
                    min--;
                    if (min.toString().length != 2) {
                      that.setData({
                        minute: '0' + min,
                        second: 59
                      })
                    } else {
                      that.setData({
                        minute: min,
                        second: 59
                      })
                    }
                  } else if (min < 0) {
                    hr--;
                    if (hr.toString().length != 2) {
                      that.setData({
                        hour: '0' + hr,
                        minute: 59
                      })
                    } else {
                      that.setData({
                        hour: hr,
                        minute: 59
                      })
                    }
                  }
                }, 1000)
              }
            } else if (res.data.code == -1) {
              that.setData({
                death_time: 2,
                death_info: res.data.msg,
                goods: res.data.data,
                group_all: res.data.data.group_all,
                one_title: 0
              });
            }
          }
        })
        clearInterval(timer1)
      }
    }, 100)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    var that = this;
    let imgUrl = that.data.goods.googs.list_img;
    wx.getSystemInfo({
      success: function (res) {
        if (res.model.indexOf('iPhone') != -1){
          imgUrl = '../../img/logo.png';
        }
      }
    })
    return {
      title: that.data.goods.activity_name,
      path: '/pages/detail/detail?id=' + that.data.id,
      imageUrl: imgUrl,
      success: function (res) {
        wx.showToast({
          title: '分享成功',
          icon: 'success',
          duration: 1500
        })
      },
      fail: function (res) {
        wx.showToast({
          title: '分享失败',
          icon: 'none',
          duration: 1500
        })
      }
    }
  }
})